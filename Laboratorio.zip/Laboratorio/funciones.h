#ifndef FUNCIONES_H
#define FUNCIONES_H
#include <stdlib.h>
#include <time.h>
#define FILA 4
#define COLUMNA 4
#define DERECHA 'h'
#define IZQUIERDA 'g'
#define ARRIBA 'y'
#define ABAJO 'b'
#define GANAR 2048

void inicializar(int matriz[FILA][COLUMNA]);
void random(int matriz[FILA][COLUMNA]);
char controles(int matriz[FILA][COLUMNA]);
void mostrar(int matriz[FILA][COLUMNA]);
void derecha(int matriz[FILA][COLUMNA]);
void izquierda(int matriz[FILA][COLUMNA]);
void arriba(int matriz[FILA][COLUMNA]);
void abajo(int matriz[FILA][COLUMNA]);
void generaDos(int matriz[FILA][COLUMNA]);
#endif
