#include<iostream>
#include <stdlib.h>
#include <time.h>
#define FILA 4
#define COLUMNA 4
#define DERECHA 'h'
#define IZQUIERDA 'g'
#define ARRIBA 'y'
#define ABAJO 'b'
#define GANAR 2048

void inicializar(int matriz[FILA][COLUMNA])//Inicializa la matriz en "0".
{
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			matriz[f][j]=0;
		}
	}
}

void random(int matriz[FILA][COLUMNA]) //Genera el numero "2" dos veces en la matriz en posiciones al azar.
{
	int contador=0;
	
	while (contador < 2) 
	{
		int f=rand()%FILA;
		int c=rand()%COLUMNA;
		if (matriz[f][c]!=2) 
		{
			matriz[f][c]=2;
			contador++;
		}
	}
	
	for (int f=0;f<FILA;f++) 
	{
		for(int c=0;c<COLUMNA;c++) 
		{
			printf(" %d ", matriz[f][c]);
		}
		printf("\n");
	}
}

char controles(int matriz[FILA][COLUMNA])//Incompleto
{
	char movimiento;
	
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			while(matriz[f][j]!=GANAR && matriz[f][j]==0)
			{
				printf("\nIngrese movimiento:");
				movimiento=getchar();
				
				switch (movimiento)
				{
				case DERECHA:derecha(matriz);
					break;
				case IZQUIERDA:izquierda(matriz);
					break;
				case ABAJO:abajo(matriz);
					break;
				case ARRIBA:arriba(matriz);
					break;
				default:
					break;
				}
			}
		}
	}
}

void derecha(int matriz[FILA][COLUMNA])
{	
	int valor,suma;
	
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			if(matriz[f][j]!=0 && j!=COLUMNA)
			{
				valor=matriz[f][j];
				matriz[f][j]=matriz[f][j+1];
				matriz[f][j+1]=valor;
			}
			
			if(matriz[f][j+1]==valor)
			{
				suma=matriz[f][j+1]+valor;
				matriz[f][j]=0;
			}
			
			system("cls");
		}
	}
}

void izquierda(int matriz[FILA][COLUMNA])
{	
	int valor,suma;
	
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			if(matriz[f][j]!=0 && j!=COLUMNA)
			{
				valor=matriz[f][j];
				matriz[f][j]=matriz[f][j-1];
				matriz[f][j-1]=valor;
			}
			
			if(matriz[f][j-1]==valor)
			{
				suma=matriz[f][j-1]+valor;
				matriz[f][j]=0;
			}
			
			system("cls");
			
		}
	}
}

void arriba(int matriz[FILA][COLUMNA])
{	
	int valor,suma;
	
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			if(matriz[f][j]!=0 && f!=FILA)
			{
				valor=matriz[f][j];
				matriz[f][j]=matriz[f-1][j];
				matriz[f-1][j]=valor;
			}
			
			if(matriz[f-1][j]==valor)
			{
				suma=matriz[f-1][j]+valor;
				matriz[f][j]=0;
			}
			
			system("cls");
			
		}
	}
}

void abajo(int matriz[FILA][COLUMNA])
{	
	int valor,suma;
	
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			if(matriz[f][j]!=0 && f!=FILA)
			{
				valor=matriz[f][j];
				matriz[f][j]=matriz[f+1][j];
				matriz[f+1][j]=valor;
			}
			
			if(matriz[f+1][j]==valor)
			{
				suma=matriz[f+1][j]+valor;
				matriz[f][j]=0;
			}
			
			system("cls");
			
		}
	}
}

void generaDos(int matriz[FILA][COLUMNA]) //Genera el numero "2" y muestra la matriz luego de confirmar un movimiento.
{
	int contador=0;
	
	while (contador < 1) 
	{
		int f=rand()%FILA;
		int c=rand()%COLUMNA;
		if (matriz[f][c]==0) 
		{
			matriz[f][c]=2;
			contador++;
		}
	}
	
	for (int f=0;f<FILA;f++) 
	{
		for(int c=0;c<COLUMNA;c++) 
		{
			printf(" %d ", matriz[f][c]);
		}
		printf("\n");
	}
}
