#include<iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;
#include "funciones.h"
#define FILA 4
#define COLUMNA 4
#define DERECHA 'h'
#define IZQUIERDA 'g'
#define ARRIBA 'y'
#define ABAJO 'b'
#define GANAR 2048

int main(int argc, char *argv[]) {
	
	srand(time(NULL));
	int matriz[FILA][COLUMNA];
	
	printf("\tBienvenido al juego 2048\n");
	printf("\n");
	
	inicializar(matriz);
	random(matriz);
	controles(matriz);
	generaDos(matriz);
	return 0;
}

