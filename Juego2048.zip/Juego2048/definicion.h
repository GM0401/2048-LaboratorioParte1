#ifndef DEFINICION_H
#define DEFINICION_H
#define A 10 // constante de alias
#define C 8 //constante de cedula
#define N 20 // constante de nombre
#define L 30 //constante de localidad
#define AP 30//constante de apellido
#define JUGADORES 10 //cantidad de jugadores
#define FILA 4#define COLUMNA 4#define GANAR 16

typedef struct _usuario{
	char subnomb[A];
	int largosubnom;
}usuario;

typedef struct _cadena{	char palabra[N];  	int largopalabra; }cadena; 

typedef struct _ape{	char apell[AP];	int largoapell;}ape;
typedef struct _lugar{	char lug[L];	int largolug;}lugar;
typedef struct _digito{	int numero[C];  	int largodigito;  }digito; typedef struct _fecha{	int dia;	int mes;	int anio;}fecha; 

typedef struct _fechaHora{	fecha momento;	int hora;	int min;}fechaHora; 

typedef struct _datosJugadas{	fechaHora jugada;
	int puntajes;
	char resultado;}datosJugadas; 
typedef struct _jugador{	cadena nombre;	ape apellido;	digito cedula;	lugar localidad;	fecha fechanac;	usuario alias;
	datosJugadas partidas[JUGADORES];
	int jugadas=0;	char estado;}jugador;

#endif
