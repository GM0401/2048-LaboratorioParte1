#include<iostream>using namespace std;#include "prototipos.h"
#include "definicion.h"
#include <string.h>int main(int argc, char *argv[]) {		srand(time(NULL));
	
	int puntaje=0;	int matriz[FILA][COLUMNA];
	int copiamatriz[FILA][COLUMNA];
	int opcion;
	char subopcion;
	jugador jugadores[JUGADORES];	int pos=0;
	usuario j;
	fecha f;
	fechaHora d;
	int u=0;
	char r;
	
	bienvenida();
	menu();
	opcion = ingopcion();
	
	while(opcion!=4)
	{	
		switch(opcion)
		{
		case 1:	submenu1();
		subopcion=ingsubopcion();
		while(subopcion!='d'&&subopcion!='D'){
			switch(subopcion)
			{
			case 'A':
			case 'a': 	alta(jugadores ,pos);
			break;
			
			case 'B':
			case 'b':	baja(jugadores, pos);
			break;
			
			case 'C':
			case 'c':	modifico(jugadores, pos);
			break;
			
			case 'd':
			case 'D': break;
			break;
			default:
				printf("no valido");
				break;
			}
			submenu1();
			subopcion=ingsubopcion();
		}
		break;
		
		case 2:	j=ingresoAlias();
				if(validoAlias(jugadores,pos,j))
				{
					u=buscoJugadores(jugadores,pos,j);
					if(jugadores[u].estado=='A'){
						d=ingresoFechaHora();
						guia();
						inicioJuego(matriz,puntaje,r);
						do{
							controles(matriz,copiamatriz,puntaje,r);
						} while(sigueJugando(matriz,puntaje,r));
						
						resultados(u,d,puntaje,jugadores,r);
					}
					else{
						printf("Usuario eliminado");
					}
				}
				else{
					printf("\nDebe ingresar un alias registrado.\n");
					getchar();
				}
		break;
			
		case 3: submenu2();	
		subopcion=ingsubopcion();
		while(subopcion!='e'&&subopcion!='E'){
			switch(subopcion)
			{
			case 'A':
			case 'a': 	listaAliasOrdenados(jugadores,pos);
			break;
			
			case 'B':
			case 'b':	listadoPartidas(jugadores,pos);
			break;
			
			case 'C':
			case 'c':	j=ingresoAlias();
				listaPorUsuario(jugadores,pos,j);
			break;
			
			case 'd':	
			case 'D':	f=ingresoFechanacimiento();
				listaPorFecha(jugadores,pos,f);
			break;
			
			case 'e':
			case 'E': break;
			break;
			default:
				printf("no valido");
				break;
			}
			submenu2();
			subopcion=ingsubopcion();
		}
		}
		menu();
		opcion = ingopcion();
	}		return 0;}