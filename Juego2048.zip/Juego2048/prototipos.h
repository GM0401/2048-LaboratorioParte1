#ifndef FUNCIONES_H#define FUNCIONES_H
#include "definicion.h"

//Interfas
void bienvenida();
void menu();
void submenu1();
void submenu2();
int ingopcion();
char ingsubopcion();
char confirmaSN();
void guia();
void error();


//ingresos
usuario ingresoAlias();
digito ingresoCedula();
cadena ingresoNombre();
ape ingresoApellido();
fecha ingresoFechanacimiento();
lugar ingresoLocalidad();
fechaHora ingresoFechaHora();
//validas
bool validoAlias(jugador jugadores[], int pos, usuario a);
bool validoCedula();
bool comparoAlias(usuario a1, usuario a2);
bool comparoFechas(fecha f1, fecha f2);
//muestro
void mostrarCedula(digito cedula);
void mostrarApellido(ape apellido);
void mostrarLocalidad(lugar localidad);
void mostrarNombre(cadena nombre);
void mostrarAlias(usuario alias);
void mostrarFechanacimiento(fecha fechanac);
void mostrarFechaHora(fechaHora jugada);
void mostrarResultados(datosJugadas partidas[],int a);
//busco
int buscoJugadores(jugador jugadores[],int pos, usuario ali);
int BuscoFechas(jugador jugadores[],int pos, fecha f);
//Usuario
void alta(jugador jugadores[],int &pos);
void baja(jugador jugadores[], int pos);
void modifico(jugador jugadores[],int pos);
//listados
void resultados(int u, fechaHora d,int puntaje, jugador jugadores[],char res);
void listaPorUsuario(jugador jugadores[],int pos, usuario a);
void listaAliasOrdenados(jugador jugadores[], int pos);
void listadoPartidas(jugador jugadores[],int pos);
void listaPorFecha(jugador jugadores[],int pos, fecha f);


//juego
void inicioJuego(int matriz[FILA][COLUMNA], int &puntaje, char &r);void inicializar(int matriz[FILA][COLUMNA]);void random(int matriz[FILA][COLUMNA]);void controles(int matriz[FILA][COLUMNA],int copiamatriz[FILA][COLUMNA],int &puntaje, char &r);void mostrar(int matriz[FILA][COLUMNA],int puntaje);void derecha(int matriz[FILA][COLUMNA], int &puntaje);void izquierda(int matriz[FILA][COLUMNA], int &puntaje);void arriba(int matriz[FILA][COLUMNA], int &puntaje);void abajo(int matriz[FILA][COLUMNA], int &puntaje);void generaDos(int matriz[FILA][COLUMNA]);
bool sigueJugando(int matriz[FILA][COLUMNA], int &puntaje,char &r);
bool perdiste(int matriz[FILA][COLUMNA]);
bool iguales(int matriz[FILA][COLUMNA]);void ganar(int puntaje,char &r);void perder(int puntaje,char &r);	
void copia(int matriz[FILA][COLUMNA],int copiamatriz[FILA][COLUMNA]);
bool mueve(int matriz[FILA][COLUMNA],int copiamatriz[FILA][COLUMNA]);
void aborta(int matriz[FILA][COLUMNA],char &r);
#endif