#include<iostream>
#include "prototipos.h"
#include "definicion.h"
#include <string.h>

void bienvenida()
{																//Cartel inicio.
	
	printf("\n\n\t||======================================||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||     Bienvendo al juego 2048          ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t|| Para ingresar al menu precione ENTER ||\n");           					
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||======================================||\n\n");
	getchar();
	system("clear");
	fpurge(stdin);
}


void menu()
{
	system("clear");
	printf("\n===========================");
	printf("\n	Menu:	");
	printf("\n   1_ Gestion usuario. ");
	printf("\n   2_ Jugar.");
	printf("\n   3_ Informes. ");
	printf("\n   4_ Salir. ");
	printf("\n===========================\n");
}


void submenu1()
{
	system("clear");
	printf("\n===========================");
	printf("\n   A_ Ingresar Usuario. ");
	printf("\n   B_ Eliminar Usuario.");
	printf("\n   C_ Modificar Usuario. ");
	printf("\n   D_ Volver al menu. ");
	printf("\n===========================\n");
}


void submenu2()
{
	system("clear");
	printf("\n===========================");
	printf("\n   A_ Listado de Usuarios. ");
	printf("\n   B_ Listado de todas las partidas jugadas.");
	printf("\n   C_ Listado de partidas por usuario. ");
	printf("\n   D_ Listado de partidas por fecha. ");
	printf("\n   E_ Volver al menu. ");
	printf("\n===========================\n");
}
	

int ingopcion()
{
	int op;
	scanf("%d",&op);
	fpurge(stdin);
	return op;
}
	
char ingsubopcion()
{
	char op;
	op = getchar();
	fpurge(stdin);
	return op;
}
	
	
char confirmaSN()
{
	
	char confirma;
	printf("\nPara confirmar precione s de lo contrario n ");
	confirma=getchar();
	fpurge(stdin);
	return confirma;
}


void guia()
{
	system("clear");
	printf("\t||======================================||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t|| Para comenzar a jugar precione ENTER ||\n");           					
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||  Los controles son: g = izquierda    ||\n");   
	printf("\t||\t\t         h = derecha    ||\n");  
	printf("\t||\t\t         y = arriba     ||\n");  
	printf("\t||\t\t         b = abajo      ||\n");  
	printf("\t||\t\t         a = salir      ||\n");  
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||======================================||\n\n");
	getchar();
	system("clear");
	fpurge(stdin);
}
	
	
void error()
{
	printf("\t||======================================||\n");					//Cartel tecla no valida.
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||     Caracter no valido               ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||  Los controles son: g = izquierda    ||\n");   
	printf("\t||\t\t         h = derecha    ||\n");  
	printf("\t||\t\t         y = arriba     ||\n");  
	printf("\t||\t\t         b = abajo      ||\n"); 
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||     Para continuar precione ENTER    ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||  \t\t\t\t        ||\n");
	printf("\t||======================================||\n\n");
	getchar();
	fpurge(stdin);
}



usuario ingresoAlias()
{				
	int ci = 0;
	usuario c;
	printf("\nIngrese alias : ");
	while(ci<A&&(c.subnomb[ci]=getchar())!='\n')
	{
		ci++;
	}
	c.largosubnom=ci;
	fpurge(stdin);
	return c;
}
	

digito ingresoCedula()
{		
	int ci = 0;
	digito c;
	printf("\nIngrese cedula sin puntos ni guion: ");	
	while(ci<C&&(c.numero[ci]=getchar())!='\n')
	{		
		c.numero[ci]=c.numero[ci]-48;
		ci++;
	}		
	c.largodigito=ci;		
	fpurge(stdin);	
	return c;
}
	

cadena ingresoNombre()
{				
	int ci = 0;
	cadena c;
	printf("\nIngrese nombre : ");
	while(ci<N&&(c.palabra[ci]=getchar())!='\n')
	{
		ci++;
	}
	c.largopalabra=ci;
	fpurge(stdin);
	return c;
}
	

ape ingresoApellido()
{				
	int ci = 0;
	ape c;
	printf("\nIngrese apellido : ");
	while(ci<AP&&(c.apell[ci]=getchar())!='\n')
	{
		ci++;
	}
	c.largoapell=ci;
	fpurge(stdin);
	return c;
}
	

fecha ingresoFechanacimiento()
{
	fecha p;	
	printf("\nIngrese fecha en formato dd/mm/aaaa y precione enter :\n ");
	scanf("%d/%d/%d",&p.dia, &p.mes, &p.anio);	
	fpurge(stdin);	
	return p;
}


lugar ingresoLocalidad()
{				
	int ci = 0;
	lugar c;
	printf("\nIngrese localidad : ");
	while(ci<L&&(c.lug[ci]=getchar())!='\n')
	{
		ci++;
	}
	c.largolug=ci;
	fpurge(stdin);
	return c;
}


fechaHora ingresoFechaHora()
{
	fechaHora p;
	system("clear");
	printf("\nIngrese fecha en formato dd/mm/aaaa y precione enter :\n ");
	scanf("%d/%d/%d",&p.momento.dia, &p.momento.mes, &p.momento.anio);	
	fpurge(stdin);
	printf("\nIngrese la hora en formato hs:min y precione enter :\n ");
	scanf("%d:%d",&p.hora, &p.min);	
	fpurge(stdin);
	return p;
}



bool validoAlias(jugador jugadores[],int pos,usuario a)
{
	int v;
	v=buscoJugadores(jugadores,pos,a);
	if(v==-1)
	{
		return false;
	}
	else
	{
		printf("Alias ya registrado\n");
		return true;
	}
}


bool validoCedula(digito cedula)
{
	bool validar=false;
	int s,m,h;
	
	s=(cedula.numero[0]*2)+(cedula.numero[1]*9)+(cedula.numero[2]*8)+(cedula.numero[3]*7)+(cedula.numero[4]*6)+(cedula.numero[5]*3)+(cedula.numero[6]*4);
	m= s%10;
	h= (10-m)%10;
	if(h==cedula.numero[7])
	{
		validar = false;
	}
	else{
		validar = true;
		printf("Cedula no valida\n ");
	}
	
	return validar;
}


bool comparoAlias(usuario a1, usuario a2)
{
	
	bool resultado = true;	
	if(a1.largosubnom == a2.largosubnom)
	{		
		for(int i=0; i<a1.largosubnom; i++)
		{			
			if(a1.subnomb[i]!=a2.subnomb[i])
			{				
				resultado = false;				
				break;
			}
		}
	}	
	else
	{		
		resultado = false;
	}	
	return resultado;
}


bool comparoFechas(fecha f1, fecha f2)
{
	
	bool resultado = true;	
	if(f1.dia == f2.dia)
	{		
		if(f1.mes == f2.mes)
		{
			if(f1.anio!=f2.anio)
			{				
				resultado = false;				
			}
		}
		else
		{
			resultado = false;
		}
	}	
	else
	{		
		resultado = false;
	}	
	return resultado;
}
	


void mostrarCedula(digito cedula)
{
	for(int i=0; i<cedula.largodigito; i++)
	{
		printf("%d",cedula.numero[i]);
	}	
	printf("\n");
}
	

void mostrarApellido(ape apellido)
{	
	for(int i=0; i<apellido.largoapell; i++)
	{
		printf("%c",apellido.apell[i]);
	}	
	printf("\n");
}
	

void mostrarLocalidad(lugar localidad)
{	
	for(int i=0; i<localidad.largolug; i++)
	{
		printf("%c",localidad.lug[i]);
	}	
	printf("\n");
}
	

void mostrarNombre(cadena nombre)
{	
	for(int i=0; i<nombre.largopalabra; i++)
	{
		printf("%c",nombre.palabra[i]);
	}	
	printf("\n");
}


void mostrarAlias(usuario alias)
{	
	for(int i=0; i<alias.largosubnom; i++)
	{
		printf("%c",alias.subnomb[i]);
	}	
	printf("\n");
}


void mostrarFechanacimiento(fecha fechanac)
{
	printf("\n%d/%d/%d",fechanac.dia, fechanac.mes, fechanac.anio);
	getchar();
}
	

void mostrarFechaHora(fechaHora jugada)
{
	printf("\n%d/%d/%d	%d:%d",jugada.momento.dia, jugada.momento.mes, jugada.momento.anio, jugada.hora, jugada.min);
	getchar();
}
	

void mostrarResultados(datosJugadas partidas[],int a)
{
	for (int i = 0; i < a; i++) 
	{
		printf("\nFecha: %d/%d/%d ", partidas[i].jugada.momento.dia, partidas[i].jugada.momento.mes, partidas[i].jugada.momento.anio);
		printf("\nHora: %d:%d ", partidas[i].jugada.hora, partidas[i].jugada.min);
		printf("\nPuntaje: %d ", partidas[i].puntajes);
		if(partidas[i].resultado=='L')
		{
			printf("\nResultado: Lograda ");
		}
		else
		{
			if(partidas[i].resultado=='N')
			{
				printf("\nResultado: No lograda ");
			}
			else
			{
				printf("\nResultado: Abortada ");
			}
		}
		printf("\n");
	}
}
	
	

int buscoJugadores(jugador jugadores[],int pos, usuario ali)
{	
	for(int i =0; i<pos; i++)
	{		
		if(comparoAlias(jugadores[i].alias,ali))
		{			
			return i;
		}
	}	
	return -1;
}

	
int BuscoFechas(jugador jugadores[],int pos, fecha f)
{
	for(int i = 0; i<pos; i++)
	{
		for(int z =0; z<jugadores[i].jugadas; z++)
		{
			if(comparoFechas(jugadores[i].partidas[z].jugada.momento,f))
			{
				return i;
			}
		}
	}
	
	return -1;
}



void alta(jugador jugadores[],int &pos)
{		
	char conf;	
	usuario a;
	int j;
	if(pos<=JUGADORES)
	{
		
		a=ingresoAlias();
		j=buscoJugadores(jugadores,pos,a);
		if(j!=-1)
		{
			if(jugadores[j].estado=='A')
			{
				printf("Alias ya registrado");
			}
			else
			{
				jugadores[j].estado='A';
			}
		}
		else
		{
			jugadores[pos].alias=a;
			do
			{
				jugadores[pos].cedula=ingresoCedula();
			} 
			while(validoCedula(jugadores[pos].cedula));
			jugadores[pos].nombre=ingresoNombre();	
			jugadores[pos].apellido=ingresoApellido();
			jugadores[pos].localidad=ingresoLocalidad();
			jugadores[pos].fechanac=ingresoFechanacimiento();
			jugadores[pos].estado='A';
			
			conf = confirmaSN();	
			if(conf=='s')
			{		
				pos++;
			}
		}
	}
	else
	{
		printf("Has alcanzado el maximo de jugadores posibles para ingresar.");
	}
}

	
void baja(jugador jugadores[], int pos)
{
	
	usuario  ali;	
	int encontrado;	
	ali = ingresoAlias();	
	encontrado = buscoJugadores(jugadores,pos,ali);	
	if(encontrado!=-1)
	{		
		if(jugadores[encontrado].estado == 'A')
		{			
			jugadores[encontrado].estado = 'I';
		}
		else
		{			
			printf("\nJugador ya eliminado");
		}
	}	
	else
	{		
		printf("\nJugador no encontrado");
	}
}
	
	
void modifico(jugador jugadores[],int pos)
{
	
	usuario ali;
	int encontrado;
	ali = ingresoAlias();
	encontrado = buscoJugadores(jugadores,pos,ali);
	
	if(encontrado!=-1)
	{
		if(jugadores[encontrado].estado=='A')
		{
			mostrarCedula(jugadores[encontrado].cedula);
			mostrarNombre(jugadores[encontrado].nombre);
			mostrarApellido(jugadores[encontrado].apellido);
			mostrarLocalidad(jugadores[encontrado].localidad);
			mostrarFechanacimiento(jugadores[encontrado].fechanac);
			
			jugadores[encontrado].localidad=ingresoLocalidad();
		}
		else
		{
			printf("\nJugador eliminado");
		}
	}
	else
	{
		printf("\nJugador no registrado");
	}
}
	

void resultados(int u, fechaHora d,int puntaje,jugador jugadores[],char res)
{
	int j;
	j=jugadores[u].jugadas;
	jugadores[u].partidas[j].jugada=d;
	jugadores[u].partidas[j].puntajes=puntaje;
	jugadores[u].partidas[j].resultado=res;
	jugadores[u].jugadas++;
}


void listaPorUsuario(jugador jugadores[],int pos, usuario a)
{	
	int c;
	
	c=buscoJugadores(jugadores,pos, a);
	if(c!=-1)
	{
		mostrarResultados(jugadores[c].partidas,jugadores[c].jugadas);
		getchar();
	}
}
	

void listaAliasOrdenados(jugador jugadores[], int pos)
{
	
	int i,j,posi;
	usuario aux;
	jugador intercambio;
	for(i=0;i<pos-1;i++)
	{
		posi=i;
		aux=jugadores[i].alias;
		for(j=i+1;j<pos;j++)
		{
			if (strcmp(jugadores[j].alias.subnomb,aux.subnomb)<= 0)
			{
				aux=jugadores[j].alias;
				posi=j;
			}
		}
		//Intercambio
		intercambio = jugadores[posi];
		jugadores[posi]=jugadores[i];
		jugadores[i]=intercambio;
	}
	
	
	for (int z= 0; z<pos; z++) 
	{
		if(jugadores[z].estado=='A')
		{
			mostrarAlias(jugadores[z].alias);
			mostrarCedula(jugadores[z].cedula);
			mostrarNombre(jugadores[z].nombre);
			mostrarApellido(jugadores[z].apellido);
			mostrarLocalidad(jugadores[z].localidad);
		}
		printf("\n");
	}
	getchar();
}
	

void listadoPartidas(jugador jugadores[],int pos)
{
	
	for (int z= 0; z<pos; z++) 
	{
		if(jugadores[z].jugadas>0)
		{
			mostrarAlias(jugadores[z].alias);
			mostrarResultados(jugadores[z].partidas,jugadores[z].jugadas);
		}
		printf("\n");
	}
	getchar();
}


void listaPorFecha(jugador jugadores[],int pos, fecha f)
{
	int e;
	e=BuscoFechas(jugadores,pos,f);
	if(e!=-1)
	{
		for(int j = 0; j<pos; j++)
		{
			for(int z =0; z<jugadores[j].jugadas; z++)
			{		
				if(comparoFechas(jugadores[j].partidas[z].jugada.momento,f))
				{			
					mostrarAlias(jugadores[j].alias);
					printf("%d:%d",jugadores[j].partidas[z].jugada.hora, jugadores[j].partidas[z].jugada.min);
					if(jugadores[j].partidas[z].resultado=='L')
					{
						printf("\nLograda");
					}
					else
					{
						if(jugadores[j].partidas[z].resultado=='N')
						{
							printf("\nNo lograda ");
						}
						else
						{
							printf("\nAbortada ");
						}
					}
					getchar();
				}
				else
				{
					printf("\nNo hay partidas jugadas en esa fecha");
					getchar();
				}
			}	
		}
	}
	getchar();
}



void inicioJuego (int matriz[FILA][COLUMNA], int &puntaje, char &r)
{				// reinicia el puntaje e inicializa la matriz.
	
	puntaje =0;
	r = ' ';
	system("clear");
	inicializar(matriz);
	
}


void inicializar(int matriz[FILA][COLUMNA])					//Inicializa la matriz en "0" y gnera dos 2.
{
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			matriz[f][j]=0;
		}
	}
	random(matriz);
}
	

void random(int matriz[FILA][COLUMNA]) 					//Genera el numero "2" dos veces en la matriz en posiciones al azar.		
{
	int contador=0;
	while (contador < 2) 
	{
		int f=rand()%FILA;
		int c=rand()%COLUMNA;
		if (matriz[f][c]!= 2) 
		{
			matriz[f][c] = 2;
			contador++;
		}
	}
	for (int f=0;f<FILA;f++) 
	{
		
		for(int c=0;c<COLUMNA;c++) 
			
		{
			
			printf(" %d |", matriz[f][c]);
			
		}
		
		printf("\n");
		
	}
	
}	
	
	
void controles(int matriz[FILA][COLUMNA],int copiamatriz[FILA][COLUMNA], int &puntaje, char &r)		//llama a las funciones de movimiento
{
	char movimiento,salida;
	

	while(sigueJugando(matriz,puntaje,r))
	{
		printf("\nIngrese movimiento:\n");
		scanf(" %c",&movimiento);
		fpurge(stdin);
		
		switch (movimiento)
		{
		case 'h':
		case 'H':
			copia(matriz,copiamatriz);
			derecha(matriz, puntaje);
			printf("precionaste: ");
			putchar(movimiento);
			if(mueve(matriz,copiamatriz))
			{
				generaDos(matriz);
			}
			break;
		case 'g':
		case 'G':
			copia(matriz,copiamatriz);
			izquierda(matriz, puntaje);	
			printf("precionaste: ");
			putchar(movimiento);
			if(mueve(matriz,copiamatriz))
			{
				generaDos(matriz);
			}
			break;
		case 'y':
		case 'Y':
			copia(matriz,copiamatriz);
			arriba(matriz, puntaje);
			printf("precionaste: ");
			putchar(movimiento);
			if(mueve(matriz,copiamatriz))
			{
				generaDos(matriz);
			}
			break;
		case 'b':
		case 'B':
			copia(matriz,copiamatriz);
			abajo(matriz, puntaje);
			printf("precionaste: ");
			putchar(movimiento);
			if(mueve(matriz,copiamatriz))
			{
				generaDos(matriz);
			}
			break;
		case 'a':
		case 'A':
			salida=confirmaSN();
			if(salida=='s'){
				aborta(matriz,r);
			}
			break;
		default:
			error();
			getchar();
		}
		system("clear");
		mostrar(matriz,puntaje);	
	}
}


void mostrar(int matriz[FILA][COLUMNA], int puntaje)
{                						  //Muestro matriz.
	printf("\nPuntos: %d\n", puntaje);
	for (int f=0;f<FILA;f++)
	{
		for(int c=0;c<COLUMNA;c++) 
		{
			printf(" %d |", matriz[f][c]);
		}
		printf("\n");
	}
}


void derecha(int matriz[FILA][COLUMNA], int &puntaje) 
{
	for (int f = 0; f < FILA; f++) 
	{
		for (int i = COLUMNA - 1; i >= 0; i--) 
		{
			if(matriz[f][i]!=0)
			{				
				for (int k = i - 1; k >= 0; k--) 
				{
					if (matriz[f][k] == matriz[f][i]) 
					{
						matriz[f][i] = matriz[f][i] * 2;
						matriz[f][k] = 0;
						puntaje = puntaje + matriz[f][i];
						break;
					} else 
					{
						if (matriz[f][k] != 0) 
						{
							break;
						}
					}
				}
			}
		}
	}
	for(int f=0;f<FILA;f++)
	{
		for(int i=COLUMNA-1;i>=0;i--)
		{
			if(matriz[f][i]==0)
			{
				for(int k=i-1;k>=0;k--)
				{
					if(matriz[f][k]!=0)
					{
						matriz[f][i]=matriz[f][k];
						matriz[f][k]=0;
						break;
					}
				}
			}
		}
	}
}	


void izquierda(int matriz[FILA][COLUMNA], int &puntaje) 
{
	for (int f = 0; f < FILA; f++) 
	{
		for (int j = 0; j < COLUMNA; j++) 
		{
			if (matriz[f][j] != 0) 
			{
				for (int k = j + 1; k < COLUMNA; k++) 
				{
					if (matriz[f][k] == matriz[f][j]) 
					{
						matriz[f][j] = matriz[f][j] * 2;
						matriz[f][k] = 0;
						puntaje = puntaje + matriz[f][j];
						break;
					} else
					{
						if (matriz[f][k] != 0) 
						{
						break;
						}
					}
				}
			}
		}
	}
	for (int f = 0; f < FILA; f++) 
	{
		for (int j = 0; j < COLUMNA; j++) 
		{
			if (matriz[f][j] == 0) 
			{
				for (int k = j + 1; k < COLUMNA; k++) 
				{
					if (matriz[f][k] != 0) 
					{
						matriz[f][j] = matriz[f][k];
						matriz[f][k] = 0;
						break;
					}
				}
			}
		}
	}
}	
	

void arriba(int matriz[FILA][COLUMNA], int &puntaje)
{
	for(int j=0; j<COLUMNA; j++)
	{
		for(int f= 0; f<FILA; f++)
		{
			if(matriz[f][j]!=0){
				for(int k=f+1; k<FILA; k++)
				{
					if(matriz[k][j]==matriz[f][j])
					{
						matriz[f][j]=matriz[f][j]*2;
						matriz[k][j]=0;
						puntaje = puntaje + matriz[f][j];
						break;
					}else
					{
						if(matriz[k][j]!=0)
						{
							break;
						}
					}
				}
			}
		}
	}
	for(int j=0; j<COLUMNA; j++)
	{
		for(int f= 0; f<FILA; f++)
		{
			if(matriz[f][j]==0){
				for(int k=f+1; k<FILA; k++)
				{
					if(matriz[k][j]!=0)
					{
						matriz[f][j]=matriz[k][j];
						matriz[k][j]=0;
						break;
					}
				}
			}
		}
	}
}


void abajo(int matriz[FILA][COLUMNA], int &puntaje) 
{
	for(int j=0;j<COLUMNA;j++)
	{
		for(int f=FILA-1;f>=0;f--)
		{
			if(matriz[f][j]!=0)
			{
				for(int k=f-1;k>=0;k--)
				{
					if(matriz[k][j]==matriz[f][j])
					{
						matriz[f][j]=matriz[f][j]*2;
						matriz[k][j]=0;
						puntaje = puntaje + matriz[f][j];
						break;
					}else
					{
						if(matriz[k][j]!=0)
						{
							break;
						}
					}
				}
			}
		}
	}
	for(int j=0;j<COLUMNA;j++)
	{
		for(int f=FILA-1;f>=0;f--)
		{
			if(matriz[f][j]==0)
			{
				for(int k=f-1;k>=0;k--)
				{
					if(matriz[k][j]!=0)
					{
						matriz[f][j]=matriz[k][j];
						matriz[k][j]=0;
						break;
					}
				}
			}
		}
	}
}	
	

void generaDos(int matriz[FILA][COLUMNA])              							//Genera el numero "2". 
{
	int f,c,contador=0;	
	while(contador!=1)
	{
		f=rand()%FILA;
		c=rand()%COLUMNA;		
		if (matriz[f][c]==0) 
		{
		matriz[f][c]=2;
		contador++;	
		}		
	}
}


bool sigueJugando(int matriz[FILA][COLUMNA], int &puntaje, char &r)
{       							//Condicion de juego y volver a jugar.
	
	bool sigue=true;
	char juega;
	
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			if(matriz[f][j]==GANAR)
			{
				system("clear");
				ganar(puntaje,r);		
				juega=getchar();
				fpurge(stdin);
				if(juega=='s')
				{
					sigue = true;
					inicioJuego(matriz,puntaje,r);
				}
				else
				{
					return false;	
				}	
			}
			else
			{
				sigue=true;
			}
		}
	}
	perdiste(matriz);
	if(perdiste(matriz))
	{
		system("clear");
		perder(puntaje,r);
		juega=getchar();
		fpurge(stdin);
		if(juega=='s')
		{
			sigue = true;
			inicioJuego(matriz,puntaje,r);
		}
		else
		{
			return false;
		}
	}
	
	return sigue;
}


bool perdiste(int matriz[FILA][COLUMNA])
{    									//Analiza la matriz para saber si se puede seguir jugando.
	bool lose=false;
	int libre;
	
	libre = 0;
	for (int f=0;f<FILA;f++)
	{
		for(int c=0;c<COLUMNA;c++) 
		{
			if(matriz[f][c]!=0)
			{
				libre++;
			}
		}
	}
	if(libre==FILA*COLUMNA)
	{
		if(iguales(matriz))
		{
			lose = false;
		}
		else
		{
			lose=true;
		}
	}
	return lose;
}
	

bool iguales(int matriz[FILA][COLUMNA])
{										//Busca numeros iguales en la matriz.
	bool busca=false;
	for(int f=0;f<FILA;f++)
	{
		for(int j=0;j<COLUMNA-1;j++)
		{	
			if(matriz[f][j]==matriz[f][j+1])
			{
				return true;
			}
			else
			{
				busca=false;
			}
		}
	}
	for(int f=0;f<FILA-1;f++)
	{
		for(int j=0;j<COLUMNA;j++)
		{	
			if(matriz[f][j]==matriz[f+1][j])
			{
				return true;
			}
			else
			{
				busca=false;
			}
		}
	}
	return busca;
}


void ganar(int puntaje,char &r)																	//Cartel de ganar y muestra puntaje.
{
	r='L';
	printf("\t||========================================||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||   	     	Has Ganado!! 	 	  ||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||	   Tu puntaje fue de %d	   	  ||\n",puntaje);
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t|| Para volver a jugar precione S y ENTER ||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||========================================||\n");
}


void perder(int puntaje,char &r)
{	
	if(r!='A')
	{
		r='N';
	}
	printf("\t||========================================||\n");					//Cartel de perder y muestra puntaje.
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||   	     	Has perdido!! 	 	  ||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||	   Tu puntaje fue de %d	   	  ||\n",puntaje);
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t|| Para volver a jugar precione S y ENTER ||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||\t\t\t\t\t  ||\n");
	printf("\t||========================================||\n");
}


void copia(int matriz[FILA][COLUMNA],int copiamatriz[FILA][COLUMNA])
{			//copio matriz para comparativas.
	
	for (int f=0;f<FILA;f++)
	{
		for(int c=0;c<COLUMNA;c++) 
		{
			copiamatriz[f][c]=matriz[f][c];
		}
	}
}


bool mueve(int matriz[FILA][COLUMNA],int copiamatriz[FILA][COLUMNA])
{			//busco si se pudo realizar un movimiento en la matriz.
	bool movio=true;
	for (int f=0;f<FILA;f++)
	{
		for(int c=0;c<COLUMNA;c++) 
		{
			if(copiamatriz[f][c]==matriz[f][c])
			{
				movio=false;
			}
			else
			{
				return true;
			}
		}
	}
	return movio;
}
	

void aborta(int matriz[FILA][COLUMNA],char &r)
{
	int j=5000;
	for (int f=0;f<FILA;f++)
	{
		for(int c=0;c<COLUMNA;c++) 
		{
			matriz[f][c]=j;
			j++;
		}
	}
	r='A';
}
	
